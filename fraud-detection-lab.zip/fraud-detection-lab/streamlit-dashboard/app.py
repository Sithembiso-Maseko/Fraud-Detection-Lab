import json
import os
from datetime import datetime

import pandas as pd
import psycopg2
from psycopg2.extras import RealDictCursor
import streamlit as st
import plotly.express as px


# ---------------------------------------------------------
# Database settings
# ---------------------------------------------------------
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "fraud_lab")
DB_USER = os.getenv("DB_USER", "fraud_user")
DB_PASSWORD = os.getenv("DB_PASSWORD", "fraud_password")


def get_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        cursor_factory=RealDictCursor,
    )


def run_query(query: str) -> pd.DataFrame:
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(query)
            rows = cur.fetchall()
    return pd.DataFrame(rows)


def load_transactions() -> pd.DataFrame:
    return run_query(
        """
        SELECT
            transaction_id,
            customer_id,
            customer_type,
            region,
            channel,
            transaction_type,
            amount,
            customer_avg_amount,
            is_new_recipient,
            is_new_device,
            transactions_last_hour,
            hour,
            created_at
        FROM transactions
        ORDER BY created_at DESC;
        """
    )


def load_predictions() -> pd.DataFrame:
    return run_query(
        """
        SELECT
            transaction_id,
            ml_score,
            rule_score,
            final_risk_score,
            risk_level,
            rule_risk_level,
            triggered_rules,
            recommendation,
            created_at
        FROM fraud_predictions
        ORDER BY created_at DESC;
        """
    )


def load_alerts() -> pd.DataFrame:
    return run_query(
        """
        SELECT
            transaction_id,
            risk_level,
            final_risk_score,
            alert_message,
            alert_status,
            created_at
        FROM fraud_alerts
        ORDER BY created_at DESC;
        """
    )


def load_joined_view() -> pd.DataFrame:
    return run_query(
        """
        SELECT
            t.transaction_id,
            t.customer_id,
            t.customer_type,
            t.region,
            t.channel,
            t.transaction_type,
            t.amount,
            t.customer_avg_amount,
            t.is_new_recipient,
            t.is_new_device,
            t.transactions_last_hour,
            t.hour,
            p.ml_score,
            p.rule_score,
            p.final_risk_score,
            p.risk_level,
            p.rule_risk_level,
            p.triggered_rules,
            p.recommendation,
            p.created_at
        FROM transactions t
        JOIN fraud_predictions p
            ON t.transaction_id = p.transaction_id
        ORDER BY p.created_at DESC;
        """
    )


def parse_rules(value):
    if not value:
        return []
    try:
        return json.loads(value)
    except Exception:
        return [str(value)]


# ---------------------------------------------------------
# Streamlit page setup
# ---------------------------------------------------------
st.set_page_config(
    page_title="Eswatini Fraud Lab",
    page_icon="🚨",
    layout="wide",
)

st.title("🚨 Eswatini Fraud Detection Lab")
st.caption(
    "Simulation-based real-time fraud and anomaly detection dashboard for Eswatini-style financial transactions."
)

st.info(
    "This dashboard uses simulated transaction data. It does not connect to real banks or process real customer information."
)


# ---------------------------------------------------------
# Sidebar
# ---------------------------------------------------------
st.sidebar.title("Navigation")

page = st.sidebar.radio(
    "Choose page",
    [
        "Overview",
        "Live Transactions",
        "Fraud Alerts",
        "Transaction Details",
        "Analytics",
    ],
)

if st.sidebar.button("Refresh Data"):
    st.rerun()


# ---------------------------------------------------------
# Load data
# ---------------------------------------------------------
try:
    transactions_df = load_transactions()
    predictions_df = load_predictions()
    alerts_df = load_alerts()
    joined_df = load_joined_view()
except Exception as e:
    st.error(f"Could not connect to PostgreSQL: {e}")
    st.stop()


# ---------------------------------------------------------
# Empty data handling
# ---------------------------------------------------------
if joined_df.empty:
    st.warning("No scored transactions found yet. Use FastAPI /score to submit a transaction first.")
    st.stop()


# ---------------------------------------------------------
# Overview page
# ---------------------------------------------------------
if page == "Overview":
    st.subheader("System Overview")

    total_transactions = len(transactions_df)
    total_predictions = len(predictions_df)
    total_alerts = len(alerts_df)
    open_alerts = len(alerts_df[alerts_df["alert_status"] == "OPEN"]) if not alerts_df.empty else 0

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("Transactions", total_transactions)
    col2.metric("Predictions", total_predictions)
    col3.metric("Total Alerts", total_alerts)
    col4.metric("Open Alerts", open_alerts)

    st.divider()

    st.subheader("Latest Scored Transactions")
    st.dataframe(
        joined_df[
            [
                "transaction_id",
                "region",
                "channel",
                "amount",
                "ml_score",
                "rule_score",
                "final_risk_score",
                "risk_level",
                "created_at",
            ]
        ],
        use_container_width=True,
    )

    st.divider()

    st.subheader("Risk Level Summary")

    risk_counts = joined_df["risk_level"].value_counts().reset_index()
    risk_counts.columns = ["risk_level", "count"]

    fig = px.bar(
        risk_counts,
        x="risk_level",
        y="count",
        title="Number of Transactions by Risk Level",
    )
    st.plotly_chart(fig, use_container_width=True)


# ---------------------------------------------------------
# Live Transactions page
# ---------------------------------------------------------
elif page == "Live Transactions":
    st.subheader("Live Transactions")

    st.dataframe(
        joined_df[
            [
                "transaction_id",
                "customer_id",
                "region",
                "channel",
                "transaction_type",
                "amount",
                "final_risk_score",
                "risk_level",
                "created_at",
            ]
        ],
        use_container_width=True,
    )


# ---------------------------------------------------------
# Fraud Alerts page
# ---------------------------------------------------------
elif page == "Fraud Alerts":
    st.subheader("Fraud Alerts")

    if alerts_df.empty:
        st.success("No fraud alerts found.")
    else:
        st.dataframe(alerts_df, use_container_width=True)

        st.divider()

        open_df = alerts_df[alerts_df["alert_status"] == "OPEN"]

        st.subheader("Open Alerts")
        if open_df.empty:
            st.success("No open alerts.")
        else:
            st.dataframe(open_df, use_container_width=True)


# ---------------------------------------------------------
# Transaction Details page
# ---------------------------------------------------------
elif page == "Transaction Details":
    st.subheader("Transaction Details")

    transaction_ids = joined_df["transaction_id"].tolist()

    selected_transaction = st.selectbox(
        "Select transaction",
        transaction_ids,
    )

    selected = joined_df[joined_df["transaction_id"] == selected_transaction].iloc[0]

    col1, col2, col3 = st.columns(3)

    col1.metric("Risk Level", selected["risk_level"])
    col2.metric("Final Risk Score", float(selected["final_risk_score"]))
    col3.metric("Amount", f"E{float(selected['amount']):,.2f}")

    st.divider()

    st.write("### Transaction Information")

    st.json(
        {
            "transaction_id": selected["transaction_id"],
            "customer_id": selected["customer_id"],
            "customer_type": selected["customer_type"],
            "region": selected["region"],
            "channel": selected["channel"],
            "transaction_type": selected["transaction_type"],
            "amount": float(selected["amount"]),
            "customer_avg_amount": float(selected["customer_avg_amount"]),
            "is_new_recipient": int(selected["is_new_recipient"]),
            "is_new_device": int(selected["is_new_device"]),
            "transactions_last_hour": int(selected["transactions_last_hour"]),
            "hour": int(selected["hour"]),
        }
    )

    st.write("### Fraud Scoring")

    st.json(
        {
            "ml_score": float(selected["ml_score"]),
            "rule_score": float(selected["rule_score"]),
            "final_risk_score": float(selected["final_risk_score"]),
            "risk_level": selected["risk_level"],
            "rule_risk_level": selected["rule_risk_level"],
            "recommendation": selected["recommendation"],
        }
    )

    st.write("### Triggered Rules")

    rules = parse_rules(selected["triggered_rules"])

    if rules:
        for rule in rules:
            st.warning(rule)
    else:
        st.success("No deterministic fraud rules were triggered.")


# ---------------------------------------------------------
# Analytics page
# ---------------------------------------------------------
elif page == "Analytics":
    st.subheader("Analytics")

    col1, col2 = st.columns(2)

    with col1:
        st.write("### Alerts by Region")
        region_alerts = joined_df[joined_df["risk_level"].isin(["HIGH", "CRITICAL"])]
        if region_alerts.empty:
            st.info("No high-risk or critical alerts yet.")
        else:
            region_counts = region_alerts["region"].value_counts().reset_index()
            region_counts.columns = ["region", "count"]
            fig_region = px.bar(
                region_counts,
                x="region",
                y="count",
                title="High/Critical Alerts by Region",
            )
            st.plotly_chart(fig_region, use_container_width=True)

    with col2:
        st.write("### Alerts by Channel")
        channel_alerts = joined_df[joined_df["risk_level"].isin(["HIGH", "CRITICAL"])]
        if channel_alerts.empty:
            st.info("No high-risk or critical alerts yet.")
        else:
            channel_counts = channel_alerts["channel"].value_counts().reset_index()
            channel_counts.columns = ["channel", "count"]
            fig_channel = px.bar(
                channel_counts,
                x="channel",
                y="count",
                title="High/Critical Alerts by Channel",
            )
            st.plotly_chart(fig_channel, use_container_width=True)

    st.divider()

    st.write("### Risk Score Distribution")

    fig_score = px.histogram(
        joined_df,
        x="final_risk_score",
        nbins=20,
        title="Distribution of Final Risk Scores",
    )
    st.plotly_chart(fig_score, use_container_width=True)