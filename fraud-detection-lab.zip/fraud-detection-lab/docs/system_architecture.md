# System Architecture

## Project Title

Real-Time Fraud and Anomaly Detection System for Financial Transactions in Eswatini's Banking Sector

## Core Idea

This project simulates Eswatini-style financial transactions and detects suspicious behaviour in real time. The system does not connect to real banks and does not process real customer data.

## Architecture Flow

```text
Synthetic Eswatini Transactions
        ↓
Python Live Transaction Sender
        ↓
FastAPI Fraud Detection API
        ↓
ML Model + Deterministic Fraud Rules
        ↓
PostgreSQL Database
        ↓
Streamlit Dashboard
        ↓
n8n Webhook
        ↓
Telegram Fraud Alert