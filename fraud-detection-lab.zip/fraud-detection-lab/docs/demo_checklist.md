# Eswatini Fraud Detection Lab Demo Checklist

## 1. Start the core system

Run from the main project folder:

```powershell
cd "C:\Users\luhle\Local Data\fraud-detection-lab"
docker compose up -d
docker ps