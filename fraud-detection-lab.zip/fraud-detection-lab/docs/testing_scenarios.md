# Testing Scenarios

## Scenario 1: Normal Transaction

### Input

A customer makes a normal mobile-money or POS transaction using a known device and known recipient.

### Expected Result

The system returns LOW risk and does not generate a Telegram alert.

### Evidence

- FastAPI response
- Dashboard transaction record

---

## Scenario 2: High-Value New Recipient Transaction

### Input

A customer sends a large amount to a new recipient.

### Expected Result

The system returns HIGH or CRITICAL risk depending on the score and triggered rules.

### Evidence

- FastAPI response
- PostgreSQL prediction record
- Dashboard alert

---

## Scenario 3: Account Takeover Pattern

### Input

A transaction is made from a new device to a new recipient at an unusual late-night hour.

### Expected Result

The system returns CRITICAL risk and sends a Telegram alert.

### Evidence

- FastAPI response
- PostgreSQL alert record
- Telegram alert

---

## Scenario 4: Card-Not-Present Fraud

### Input

An online/card-not-present transaction is made for a high amount using a new recipient and new device.

### Expected Result

The system returns CRITICAL risk and sends an alert.

### Evidence

- Dashboard Fraud Alerts page
- Telegram alert
- Triggered rules

---

## Scenario 5: Live Transaction Stream

### Input

The live transaction sender sends many transactions from the simulated dataset.

### Expected Result

The dashboard updates with multiple transactions, and HIGH/CRITICAL transactions generate alerts.

### Evidence

- Live sender terminal
- Streamlit dashboard
- Telegram alerts