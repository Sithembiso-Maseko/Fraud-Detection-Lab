# Run Commands

## Start core system

```powershell
cd "C:\Users\luhle\Local Data\fraud-detection-lab"
docker compose up -d