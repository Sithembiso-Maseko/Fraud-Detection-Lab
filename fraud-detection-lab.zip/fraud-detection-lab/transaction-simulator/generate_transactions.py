import csv
import random
import uuid
from datetime import datetime, timedelta
from pathlib import Path

# Output path
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

OUTPUT_FILE = DATA_DIR / "transactions.csv"

REGIONS = ["Manzini", "Hhohho", "Lubombo", "Shiselweni"]

CHANNELS = [
    "mobile_money",
    "online_banking",
    "atm",
    "pos",
    "card_not_present"
]

TRANSACTION_TYPES = [
    "transfer",
    "withdrawal",
    "deposit",
    "bill_payment",
    "airtime_purchase",
    "merchant_payment",
    "online_payment"
]

CUSTOMER_TYPES = [
    "normal_customer",
    "salary_customer",
    "student_customer",
    "small_business_owner",
    "mobile_money_agent"
]

FRAUD_SCENARIOS = [
    "account_takeover",
    "repeated_small_transfers",
    "card_not_present_fraud",
    "new_recipient_high_amount",
    "unusual_time_high_amount"
]


def generate_customer_id(region: str) -> str:
    prefix = region[:3].upper()
    number = random.randint(1, 999)
    return f"CUST-{prefix}-{number:03d}"


def generate_recipient_id(new_recipient: bool) -> str:
    if new_recipient:
        return f"REC-NEW-{random.randint(1000, 9999)}"
    return f"REC-{random.randint(1, 500):03d}"


def generate_device_id(new_device: bool) -> str:
    if new_device:
        return f"DEV-NEW-{random.randint(1000, 9999)}"
    return f"DEV-{random.randint(1, 300):03d}"


def generate_normal_transaction(index: int) -> dict:
    region = random.choice(REGIONS)
    channel = random.choice(CHANNELS)
    transaction_type = random.choice(TRANSACTION_TYPES)

    customer_avg_amount = random.randint(100, 1200)
    amount = max(10, round(random.normalvariate(customer_avg_amount, customer_avg_amount * 0.25), 2))

    hour = random.randint(7, 21)

    return {
        "transaction_id": f"TXN-{index:06d}",
        "timestamp": (datetime.now() - timedelta(minutes=random.randint(0, 10000))).isoformat(timespec="seconds"),
        "customer_id": generate_customer_id(region),
        "customer_type": random.choice(CUSTOMER_TYPES),
        "region": region,
        "channel": channel,
        "transaction_type": transaction_type,
        "amount": amount,
        "customer_avg_amount": customer_avg_amount,
        "recipient_id": generate_recipient_id(new_recipient=False),
        "device_id": generate_device_id(new_device=False),
        "is_new_recipient": 0,
        "is_new_device": 0,
        "transactions_last_hour": random.randint(0, 3),
        "hour": hour,
        "fraud_scenario": "normal",
        "label": 0
    }


def generate_fraud_transaction(index: int) -> dict:
    region = random.choice(REGIONS)
    fraud_scenario = random.choice(FRAUD_SCENARIOS)

    customer_avg_amount = random.randint(100, 1000)

    is_new_recipient = 0
    is_new_device = 0
    transactions_last_hour = random.randint(1, 5)
    hour = random.randint(6, 22)
    channel = random.choice(CHANNELS)
    transaction_type = random.choice(TRANSACTION_TYPES)
    amount = random.randint(1500, 9000)

    if fraud_scenario == "account_takeover":
        is_new_device = 1
        is_new_recipient = 1
        amount = random.randint(5000, 15000)
        hour = random.choice([0, 1, 2, 3, 4])
        channel = random.choice(["online_banking", "mobile_money"])

    elif fraud_scenario == "repeated_small_transfers":
        is_new_recipient = 1
        amount = random.randint(200, 900)
        transactions_last_hour = random.randint(6, 15)
        channel = "mobile_money"
        transaction_type = "transfer"

    elif fraud_scenario == "card_not_present_fraud":
        is_new_recipient = 1
        amount = random.randint(1000, 7000)
        transactions_last_hour = random.randint(4, 10)
        channel = "card_not_present"
        transaction_type = "online_payment"

    elif fraud_scenario == "new_recipient_high_amount":
        is_new_recipient = 1
        amount = random.randint(4000, 12000)
        channel = random.choice(["mobile_money", "online_banking"])
        transaction_type = "transfer"

    elif fraud_scenario == "unusual_time_high_amount":
        amount = random.randint(4000, 10000)
        hour = random.choice([0, 1, 2, 3, 4])
        channel = random.choice(["mobile_money", "online_banking"])

    return {
        "transaction_id": f"TXN-{index:06d}",
        "timestamp": (datetime.now() - timedelta(minutes=random.randint(0, 10000))).isoformat(timespec="seconds"),
        "customer_id": generate_customer_id(region),
        "customer_type": random.choice(CUSTOMER_TYPES),
        "region": region,
        "channel": channel,
        "transaction_type": transaction_type,
        "amount": amount,
        "customer_avg_amount": customer_avg_amount,
        "recipient_id": generate_recipient_id(new_recipient=bool(is_new_recipient)),
        "device_id": generate_device_id(new_device=bool(is_new_device)),
        "is_new_recipient": is_new_recipient,
        "is_new_device": is_new_device,
        "transactions_last_hour": transactions_last_hour,
        "hour": hour,
        "fraud_scenario": fraud_scenario,
        "label": 1
    }


def main():
    normal_count = 5000
    fraud_count = 500

    transactions = []

    for i in range(1, normal_count + 1):
        transactions.append(generate_normal_transaction(i))

    for i in range(normal_count + 1, normal_count + fraud_count + 1):
        transactions.append(generate_fraud_transaction(i))

    random.shuffle(transactions)

    fieldnames = [
        "transaction_id",
        "timestamp",
        "customer_id",
        "customer_type",
        "region",
        "channel",
        "transaction_type",
        "amount",
        "customer_avg_amount",
        "recipient_id",
        "device_id",
        "is_new_recipient",
        "is_new_device",
        "transactions_last_hour",
        "hour",
        "fraud_scenario",
        "label"
    ]

    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(transactions)

    print(f"Generated {len(transactions)} transactions")
    print(f"Saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()