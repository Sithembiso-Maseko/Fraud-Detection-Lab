import time
import random
from pathlib import Path

import pandas as pd
import requests


BASE_DIR = Path(__file__).resolve().parents[1]
DATA_FILE = BASE_DIR / "data" / "transactions.csv"

API_URL = "http://localhost:8000/score"


def convert_row_to_transaction(row: pd.Series) -> dict:
    return {
        "transaction_id": str(row["transaction_id"]),
        "customer_id": str(row["customer_id"]),
        "customer_type": str(row["customer_type"]),
        "region": str(row["region"]),
        "channel": str(row["channel"]),
        "transaction_type": str(row["transaction_type"]),
        "amount": float(row["amount"]),
        "customer_avg_amount": float(row["customer_avg_amount"]),
        "recipient_id": str(row["recipient_id"]),
        "device_id": str(row["device_id"]),
        "is_new_recipient": int(row["is_new_recipient"]),
        "is_new_device": int(row["is_new_device"]),
        "transactions_last_hour": int(row["transactions_last_hour"]),
        "hour": int(row["hour"]),
    }


def main():
    if not DATA_FILE.exists():
        raise FileNotFoundError(f"Could not find dataset: {DATA_FILE}")

    df = pd.read_csv(DATA_FILE)

    # Shuffle transactions to simulate mixed real-time activity.
    df = df.sample(frac=1, random_state=random.randint(1, 9999)).reset_index(drop=True)

    print(f"Loaded {len(df)} transactions from {DATA_FILE}")
    print(f"Sending transactions to {API_URL}")
    print("Press CTRL + C to stop.\n")

    sent_count = 0
    error_count = 0

    for _, row in df.iterrows():
        transaction = convert_row_to_transaction(row)

        try:
            response = requests.post(API_URL, json=transaction, timeout=10)

            if response.status_code == 200:
                result = response.json()
                sent_count += 1

                print(
                    f"[{sent_count}] {result['transaction_id']} "
                    f"| risk={result['risk_level']} "
                    f"| score={result['final_risk_score']} "
                    f"| amount=E{transaction['amount']}"
                )
            else:
                error_count += 1
                print(
                    f"[ERROR] {transaction['transaction_id']} "
                    f"status={response.status_code} "
                    f"message={response.text}"
                )

        except Exception as error:
            error_count += 1
            print(f"[ERROR] {transaction['transaction_id']} {error}")

        # Delay to make it look like live streaming.
        time.sleep(0.5)

    print("\nDone.")
    print(f"Sent successfully: {sent_count}")
    print(f"Errors: {error_count}")


if __name__ == "__main__":
    main()