CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(100) UNIQUE NOT NULL,
    customer_id VARCHAR(100) NOT NULL,
    customer_type VARCHAR(100),
    region VARCHAR(100),
    channel VARCHAR(100),
    transaction_type VARCHAR(100),
    amount NUMERIC(12, 2),
    customer_avg_amount NUMERIC(12, 2),
    recipient_id VARCHAR(100),
    device_id VARCHAR(100),
    is_new_recipient INTEGER,
    is_new_device INTEGER,
    transactions_last_hour INTEGER,
    hour INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fraud_predictions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(100) NOT NULL,
    ml_score NUMERIC(6, 4),
    rule_score NUMERIC(6, 4),
    final_risk_score NUMERIC(6, 4),
    risk_level VARCHAR(50),
    rule_risk_level VARCHAR(50),
    triggered_rules TEXT,
    decision_source TEXT,
    recommendation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fraud_alerts (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(100) NOT NULL,
    risk_level VARCHAR(50),
    final_risk_score NUMERIC(6, 4),
    alert_message TEXT,
    alert_status VARCHAR(50) DEFAULT 'OPEN',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);