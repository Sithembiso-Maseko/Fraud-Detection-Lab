import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
import joblib

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_FILE = BASE_DIR / "data" / "transactions.csv"
MODEL_DIR = BASE_DIR / "fraud-api" / "models"
MODEL_DIR.mkdir(parents=True, exist_ok=True)

MODEL_FILE = MODEL_DIR / "fraud_model.pkl"

def main():
    print("Loading dataset...")
    df = pd.read_csv(DATA_FILE)

    print(f"Dataset shape: {df.shape}")
    print("\nLabel distribution:")
    print(df["label"].value_counts())

    # Features used for the first model
    numeric_features = [
        "amount",
        "customer_avg_amount",
        "is_new_recipient",
        "is_new_device",
        "transactions_last_hour",
        "hour"
    ]

    categorical_features = [
        "customer_type",
        "region",
        "channel",
        "transaction_type"
    ]

    features = numeric_features + categorical_features
    target = "label"

    X = df[features]
    y = df[target]

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y
    )

    # Preprocessing for categorical features
    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
            ("num", "passthrough", numeric_features)
        ]
    )

    # Random Forest model
    model = RandomForestClassifier(
        n_estimators=100,
        random_state=42,
        class_weight="balanced"
    )

    pipeline = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("model", model)
        ]
    )

    print("\nTraining Random Forest model...")
    pipeline.fit(X_train, y_train)

    print("\nEvaluating model...")
    y_pred = pipeline.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    print("\nModel Results")
    print("----------------------------")
    print(f"Accuracy : {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall   : {recall:.4f}")
    print(f"F1-score : {f1:.4f}")

    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred))

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    joblib.dump(pipeline, MODEL_FILE)
    print(f"\nModel saved to: {MODEL_FILE}")

if __name__ == "__main__":
    main()