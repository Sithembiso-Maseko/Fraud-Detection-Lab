def evaluate_rules(transaction: dict) -> dict:
    """
    Deterministic fraud rule engine.

    This does not use AI.
    It checks clear fraud indicators and returns:
    - rule_score
    - triggered_rules
    - rule_risk_level

    The ML model and this rule engine will later be combined
    inside the FastAPI fraud scoring service.
    """

    triggered_rules = []
    score = 0.0

    amount = float(transaction.get("amount", 0))
    customer_avg_amount = float(transaction.get("customer_avg_amount", 1))
    is_new_device = int(transaction.get("is_new_device", 0))
    is_new_recipient = int(transaction.get("is_new_recipient", 0))
    transactions_last_hour = int(transaction.get("transactions_last_hour", 0))
    hour = int(transaction.get("hour", 12))
    channel = str(transaction.get("channel", "")).lower()
    transaction_type = str(transaction.get("transaction_type", "")).lower()

    # Rule 1: Very large transaction
    if amount >= 5000:
        triggered_rules.append("Large transaction amount")
        score += 0.25

    # Rule 2: Amount is much higher than customer's normal behaviour
    if customer_avg_amount > 0 and amount >= customer_avg_amount * 4:
        triggered_rules.append("Amount is much higher than customer's normal average")
        score += 0.25

    # Rule 3: New device with high amount
    if is_new_device == 1 and amount >= 2000:
        triggered_rules.append("New device used for high-value transaction")
        score += 0.20

    # Rule 4: New recipient with high amount
    if is_new_recipient == 1 and amount >= 3000:
        triggered_rules.append("High-value transaction to a new recipient")
        score += 0.20

    # Rule 5: Unusual transaction time
    if hour >= 0 and hour <= 4:
        triggered_rules.append("Transaction occurred at unusual late-night hour")
        score += 0.15

    # Rule 6: Repeated transfers in a short time
    if transactions_last_hour >= 6:
        triggered_rules.append("High number of transactions within the last hour")
        score += 0.20

    # Rule 7: Card-not-present online risk
    if channel == "card_not_present" or transaction_type == "online_payment":
        if amount >= 1000 and is_new_recipient == 1:
            triggered_rules.append("Card-not-present or online payment risk with new recipient")
            score += 0.20

    # Rule 8: Mobile money rapid transfer pattern
    if channel == "mobile_money" and transactions_last_hour >= 5:
        triggered_rules.append("Possible mobile money rapid-transfer pattern")
        score += 0.15

    # Cap score at 1.0
    rule_score = min(score, 1.0)

    if rule_score >= 0.85:
        rule_risk_level = "CRITICAL"
    elif rule_score >= 0.60:
        rule_risk_level = "HIGH"
    elif rule_score >= 0.30:
        rule_risk_level = "MEDIUM"
    else:
        rule_risk_level = "LOW"

    return {
        "rule_score": round(rule_score, 4),
        "triggered_rules": triggered_rules,
        "rule_risk_level": rule_risk_level
    }