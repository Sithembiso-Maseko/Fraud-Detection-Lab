from rules.fraud_rules import evaluate_rules

transaction = {
    "transaction_id": "TXN-TEST-001",
    "amount": 8500,
    "customer_avg_amount": 500,
    "is_new_device": 1,
    "is_new_recipient": 1,
    "transactions_last_hour": 7,
    "hour": 2,
    "channel": "mobile_money",
    "transaction_type": "transfer"
}

result = evaluate_rules(transaction)
print(result)