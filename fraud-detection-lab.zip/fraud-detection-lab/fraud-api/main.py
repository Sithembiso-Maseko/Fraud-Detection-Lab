from pathlib import Path
from typing import List, Dict, Any

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from rules.fraud_rules import evaluate_rules
from database import save_transaction_and_prediction
from alert_client import send_n8n_fraud_alert

# ---------------------------------------------------------
# Paths
# ---------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
MODEL_FILE = BASE_DIR / "models" / "fraud_model.pkl"


# ---------------------------------------------------------
# Load ML model
# ---------------------------------------------------------
if not MODEL_FILE.exists():
    raise FileNotFoundError(
        f"Model file not found at {MODEL_FILE}. "
        "Please run training/train_model.py first."
    )

model = joblib.load(MODEL_FILE)


# ---------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------
app = FastAPI(
    title="Eswatini Fraud Detection API",
    description="Real-time fraud and anomaly detection API for simulated Eswatini financial transactions.",
    version="1.0.0"
)


# ---------------------------------------------------------
# Request and response schemas
# ---------------------------------------------------------
class TransactionRequest(BaseModel):
    transaction_id: str = Field(..., example="TXN-000001")
    customer_id: str = Field(..., example="CUST-MAN-001")
    customer_type: str = Field(..., example="normal_customer")
    region: str = Field(..., example="Manzini")
    channel: str = Field(..., example="mobile_money")
    transaction_type: str = Field(..., example="transfer")
    amount: float = Field(..., example=8500)
    customer_avg_amount: float = Field(..., example=500)
    recipient_id: str = Field(..., example="REC-NEW-9911")
    device_id: str = Field(..., example="DEV-NEW-1044")
    is_new_recipient: int = Field(..., example=1)
    is_new_device: int = Field(..., example=1)
    transactions_last_hour: int = Field(..., example=7)
    hour: int = Field(..., example=2)


class FraudScoreResponse(BaseModel):
    transaction_id: str
    ml_score: float
    rule_score: float
    final_risk_score: float
    risk_level: str
    triggered_rules: List[str]
    rule_risk_level: str
    decision_source: str
    recommendation: str


# ---------------------------------------------------------
# Helper functions
# ---------------------------------------------------------
def get_risk_level(score: float) -> str:
    if score >= 0.85:
        return "CRITICAL"
    elif score >= 0.65:
        return "HIGH"
    elif score >= 0.35:
        return "MEDIUM"
    return "LOW"


def get_recommendation(risk_level: str) -> str:
    if risk_level == "CRITICAL":
        return "Immediate analyst review required. Temporarily hold or verify the transaction before completion."
    elif risk_level == "HIGH":
        return "Fraud analyst review recommended. Apply step-up verification if this were a real system."
    elif risk_level == "MEDIUM":
        return "Monitor the transaction and customer behaviour. No immediate block required in this simulation."
    return "No suspicious activity detected. Transaction appears normal."


def prepare_model_input(transaction: Dict[str, Any]) -> pd.DataFrame:
    """
    The model was trained using these exact features:
    numeric_features:
        amount, customer_avg_amount, is_new_recipient,
        is_new_device, transactions_last_hour, hour

    categorical_features:
        customer_type, region, channel, transaction_type
    """

    features = {
        "amount": transaction["amount"],
        "customer_avg_amount": transaction["customer_avg_amount"],
        "is_new_recipient": transaction["is_new_recipient"],
        "is_new_device": transaction["is_new_device"],
        "transactions_last_hour": transaction["transactions_last_hour"],
        "hour": transaction["hour"],
        "customer_type": transaction["customer_type"],
        "region": transaction["region"],
        "channel": transaction["channel"],
        "transaction_type": transaction["transaction_type"],
    }

    return pd.DataFrame([features])


def score_transaction(transaction: Dict[str, Any]) -> Dict[str, Any]:
    model_input = prepare_model_input(transaction)

    # Probability that transaction is fraud.
    # Class 1 = fraud/suspicious.
    if hasattr(model, "predict_proba"):
        ml_score = float(model.predict_proba(model_input)[0][1])
    else:
        ml_score = float(model.predict(model_input)[0])

    rule_result = evaluate_rules(transaction)
    rule_score = float(rule_result["rule_score"])

    # Weighted score:
    # 60% model + 40% deterministic rules.
    final_risk_score = (0.6 * ml_score) + (0.4 * rule_score)
    final_risk_score = round(final_risk_score, 4)

    risk_level = get_risk_level(final_risk_score)

    return {
        "transaction_id": transaction["transaction_id"],
        "ml_score": round(ml_score, 4),
        "rule_score": round(rule_score, 4),
        "final_risk_score": final_risk_score,
        "risk_level": risk_level,
        "triggered_rules": rule_result["triggered_rules"],
        "rule_risk_level": rule_result["rule_risk_level"],
        "decision_source": "ML model + deterministic fraud rules. AI is not used to make the fraud decision.",
        "recommendation": get_recommendation(risk_level),
    }


# ---------------------------------------------------------
# API routes
# ---------------------------------------------------------
@app.get("/")
def root():
    return {
        "message": "Eswatini Fraud Detection API is running",
        "docs": "/docs",
        "health": "/health"
    }


@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "model_loaded": MODEL_FILE.exists(),
        "model_path": str(MODEL_FILE)
    }


@app.post("/score", response_model=FraudScoreResponse)
def score_single_transaction(transaction: TransactionRequest):
    try:
        transaction_dict = transaction.model_dump()

        result = score_transaction(transaction_dict)

        save_transaction_and_prediction(transaction_dict, result)

        send_n8n_fraud_alert(transaction_dict, result)

        return result
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error))


@app.post("/score-batch")
def score_batch_transactions(transactions: List[TransactionRequest]):
    try:
        results = []

        for transaction in transactions:
            transaction_dict = transaction.model_dump()

            result = score_transaction(transaction_dict)

            save_transaction_and_prediction(transaction_dict, result)

            send_n8n_fraud_alert(transaction_dict, result)

            results.append(result)

        return {
            "total_transactions": len(results),
            "results": results
        }
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error))