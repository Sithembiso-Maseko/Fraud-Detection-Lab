import os
import requests


N8N_ALERT_WEBHOOK_URL = os.getenv(
    "N8N_ALERT_WEBHOOK_URL",
    "http://host.docker.internal:5678/webhook/fraud-alert"
)


def send_n8n_fraud_alert(transaction: dict, result: dict) -> bool:
    """
    Sends HIGH/CRITICAL fraud alerts to n8n.

    Important:
    - Fraud decision is already made by ML + deterministic rules.
    - n8n only handles notification delivery.
    """

    if result.get("risk_level") not in ["HIGH", "CRITICAL"]:
        return False

    payload = {
        "transaction_id": result.get("transaction_id"),
        "risk_level": result.get("risk_level"),
        "final_risk_score": result.get("final_risk_score"),
        "ml_score": result.get("ml_score"),
        "rule_score": result.get("rule_score"),
        "amount": transaction.get("amount"),
        "customer_id": transaction.get("customer_id"),
        "region": transaction.get("region"),
        "channel": transaction.get("channel"),
        "transaction_type": transaction.get("transaction_type"),
        "triggered_rules": result.get("triggered_rules", []),
        "recommendation": result.get("recommendation"),
        "decision_source": result.get("decision_source"),
    }

    try:
        response = requests.post(
            N8N_ALERT_WEBHOOK_URL,
            json=payload,
            timeout=5
        )

        response.raise_for_status()
        return True

    except Exception as error:
        print(f"[WARN] Failed to send n8n fraud alert: {error}")
        return False