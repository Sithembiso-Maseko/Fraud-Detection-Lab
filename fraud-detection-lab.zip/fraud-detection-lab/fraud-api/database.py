import os
import json
import psycopg2
from psycopg2.extras import RealDictCursor


DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "fraud_lab")
DB_USER = os.getenv("DB_USER", "fraud_user")
DB_PASSWORD = os.getenv("DB_PASSWORD", "fraud_password")


def get_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        cursor_factory=RealDictCursor
    )


def save_transaction_and_prediction(transaction: dict, result: dict):
    triggered_rules_text = json.dumps(result.get("triggered_rules", []))

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO transactions (
                    transaction_id,
                    customer_id,
                    customer_type,
                    region,
                    channel,
                    transaction_type,
                    amount,
                    customer_avg_amount,
                    recipient_id,
                    device_id,
                    is_new_recipient,
                    is_new_device,
                    transactions_last_hour,
                    hour
                )
                VALUES (
                    %(transaction_id)s,
                    %(customer_id)s,
                    %(customer_type)s,
                    %(region)s,
                    %(channel)s,
                    %(transaction_type)s,
                    %(amount)s,
                    %(customer_avg_amount)s,
                    %(recipient_id)s,
                    %(device_id)s,
                    %(is_new_recipient)s,
                    %(is_new_device)s,
                    %(transactions_last_hour)s,
                    %(hour)s
                )
                ON CONFLICT (transaction_id) DO NOTHING;
                """,
                transaction
            )

            cur.execute(
                """
                INSERT INTO fraud_predictions (
                    transaction_id,
                    ml_score,
                    rule_score,
                    final_risk_score,
                    risk_level,
                    rule_risk_level,
                    triggered_rules,
                    decision_source,
                    recommendation
                )
                VALUES (
                    %(transaction_id)s,
                    %(ml_score)s,
                    %(rule_score)s,
                    %(final_risk_score)s,
                    %(risk_level)s,
                    %(rule_risk_level)s,
                    %(triggered_rules)s,
                    %(decision_source)s,
                    %(recommendation)s
                );
                """,
                {
                    "transaction_id": result["transaction_id"],
                    "ml_score": result["ml_score"],
                    "rule_score": result["rule_score"],
                    "final_risk_score": result["final_risk_score"],
                    "risk_level": result["risk_level"],
                    "rule_risk_level": result["rule_risk_level"],
                    "triggered_rules": triggered_rules_text,
                    "decision_source": result["decision_source"],
                    "recommendation": result["recommendation"]
                }
            )

            if result["risk_level"] in ["HIGH", "CRITICAL"]:
                cur.execute(
                    """
                    INSERT INTO fraud_alerts (
                        transaction_id,
                        risk_level,
                        final_risk_score,
                        alert_message
                    )
                    VALUES (
                        %(transaction_id)s,
                        %(risk_level)s,
                        %(final_risk_score)s,
                        %(alert_message)s
                    );
                    """,
                    {
                        "transaction_id": result["transaction_id"],
                        "risk_level": result["risk_level"],
                        "final_risk_score": result["final_risk_score"],
                        "alert_message": result["recommendation"]
                    }
                )

        conn.commit()